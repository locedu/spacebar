# spacebar

## summary

capstone project: social media site
application: node express, postgres, prisma

## version
v.0.001

## notes

- Procfile is required for AWS Elastic Beanstalk to ensure that the build script in package.json is detected and run.